close all;clear;
imgRoot='C:\Users\��\Desktop\PKU80\D\';
imnames=dir([imgRoot '*' 'png']);

for ii=1:length(imnames);
    imname=[imgRoot imnames(ii).name]; 
    f =(imread(imname));
    Result_path = 'C:\Users\��\Desktop\PKU80\2\';
    f = 255-f;
% g=medfilt2(f);
    imwrite( f,[Result_path imnames(ii).name(1:end-4) '.png'], 'png');
% imshow(BCSN_map);
end